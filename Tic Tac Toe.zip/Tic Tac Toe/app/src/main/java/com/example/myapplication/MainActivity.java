package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    int[] gameState = {2,2,2,2,2,2,2,2,2};
    int activeplayer = 0;
    int[][] winpositions = {{0,1,2},{3,4,5},{6,7,8},{0,4,8},{2,4,6},{0,3,6},{1,4,7},{2,5,8}};

    public void touch(View view){
        ImageView img = (ImageView) view;
        int touched = Integer.parseInt(img.getTag().toString());
        TextView s = findViewById(R.id.status);
        if(gameState[touched] == 2){
            img.setTranslationY(-1000f);
           gameState[touched] = activeplayer;
           if (activeplayer == 0){
               img.setImageResource(R.drawable.x);
               activeplayer = 1;
               s.setText("0's turn to play");
           }
           else{
               img.setTranslationY(-1000f);
               img.setImageResource(R.drawable.o);
               activeplayer = 0;
               s.setText("X's Turn to play");
           }
            img.animate().translationYBy(1000f).setDuration(300);
        }
        for(int[]winposition : winpositions){
            if(gameState[winposition[0]] == gameState[winposition[1]] && gameState[winposition[2]] == gameState[winposition[1]] && gameState[winposition[0]]!=2){
                if(activeplayer == 0){
                    s.setText("X has won the game");
                }
                else{
                    s.setText("Y has won the game");
                }
                ((ImageView)findViewById(R.id.i0)).setClickable(false);
                ((ImageView)findViewById(R.id.i1)).setClickable(false);
                ((ImageView)findViewById(R.id.i2)).setClickable(false);
                ((ImageView)findViewById(R.id.i3)).setClickable(false);
                ((ImageView)findViewById(R.id.i4)).setClickable(false);
                ((ImageView)findViewById(R.id.i5)).setClickable(false);
                ((ImageView)findViewById(R.id.i6)).setClickable(false);
                ((ImageView)findViewById(R.id.i7)).setClickable(false);
                ((ImageView)findViewById(R.id.i8)).setClickable(false);

            }
        }
    }

    }
